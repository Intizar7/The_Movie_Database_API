package com.najimaddinova.moviesbyinteraktifkredi.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.najimaddinova.moviesbyinteraktifkredi.R;

public class FragmentNowPlaying extends Fragment {

    View v_nowplaying;

    public FragmentNowPlaying() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v_nowplaying = inflater.inflate(R.layout.now_playing_fragment,container,false);
        return v_nowplaying;
    }
}
