package com.najimaddinova.moviesbyinteraktifkredi;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;
import com.najimaddinova.moviesbyinteraktifkredi.fragment.FragmentNowPlaying;
import com.najimaddinova.moviesbyinteraktifkredi.fragment.FragmentTopRated;
import com.najimaddinova.moviesbyinteraktifkredi.fragment.FragmentUpcoming;

public class MainActivity extends AppCompatActivity {

    private TabLayout tabLayout;
    private ViewPager viewPager;
    private MoviesAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tabLayout = findViewById(R.id.tabLayoutId);
        viewPager = findViewById(R.id.viewPages);
        adapter = new MoviesAdapter(getSupportFragmentManager());

        adapter.addFragment(new FragmentTopRated(),"Top Rated");
        adapter.addFragment(new FragmentUpcoming(),"Upcoming");
        adapter.addFragment(new FragmentNowPlaying(),"Now Playing");
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setElevation(0);
    }
}
